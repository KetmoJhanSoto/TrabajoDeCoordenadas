package TrabajoMapa;
  public class MapaCoordenada {
    public double lat;
    public double lonj;
  }